package com.cg.apps.customermgt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomermgtApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomermgtApplication.class, args);
	}

}
